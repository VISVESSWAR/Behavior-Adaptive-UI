export const ACTION_SPACE = {
  0: "noop",

  1: "button_up",
  2: "button_down",

  3: "text_up",
  4: "text_down",

  5: "font_up",
  6: "font_down",

  7: "spacing_up",
  8: "spacing_down",

  9: "enable_tooltips",
};
